package springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import springmvc.model.User;

@Controller
public class ContactoController {
	
	
	@Autowired
	private springmvc.service.UserService userService;
	
	
	@ModelAttribute
	public void CommonDAteForModel(Model m) {
		m.addAttribute("Header", "Learn code with durgesh tiwari");
		m.addAttribute("Desc", "home for programmer");
		System.out.println("adding common data to mode");
	}
	

	@RequestMapping("/contact")
	public String showForm(Model m) {
		System.out.println("creating form");
		return "contact";
	}

	@RequestMapping(path = "/processform", method = RequestMethod.POST)
	/*
	 * public String handleForm(HttpServletRequest request) { // gy thorough the
	 * http servlet request String email=request.getParameter("email");
	 * System.out.println("user email is "+email); return "";
	 * 
	 */

	// using handler
	/*
	  public String handleForm(@RequestParam("email") String userEmail,
	  
	  @RequestParam("userName") String userName,
	  
	  @RequestParam("password") String password, Model model) {
	  System.out.println("user email" + userEmail); System.out.println("user name "
	  + userName); System.out.println("user password " + password);
	  
	  
	  model.addAttribute("name", userName); model.addAttribute("email", userEmail);
	  model.addAttribute("password", password); return "success";
	  
	 */
	
	
	
	
	
	
// withour annotaion	
	
/*	
	public String handleForm(@RequestParam(name="email", required = false) String userEmail, @RequestParam("userName") String userName,
			@RequestParam("password") String password, Model model) {
		System.out.println("user email" + userEmail);
		System.out.println("user name " + userName);
		System.out.println("user password " + password);

		User user=new User();
		user.setEmail(userEmail);
		user.setUserName(userName);
		user.setPassword(password);
	
		System.out.println(user);
		
		model.addAttribute("user", user);
		return "success";
	}
	*/
	
//model attribute	
	
	public String handleForm(@ModelAttribute User user, Model model ) {
				System.out.println(user);
				if(user.getUserName().isEmpty()) {
					if(user.getPassword().isEmpty())
						if(user.getEmail().isEmpty()){
				{
					return "redirect:/contact";
				}
				}}
				
				int createdUser=this.userService.createUser(user);
				model.addAttribute("msg", "user created with id " +createdUser);
	//	model.addAttribute("user", user);
		return "success";	
	}
	
	
	
	
	
	
}
