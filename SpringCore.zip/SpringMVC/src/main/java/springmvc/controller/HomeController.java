package springmvc.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/first")
public class HomeController {

	
// for send data from controller ot view	
	@RequestMapping("/home")
//	for the method value
//	@RequestMapping(path="/home", method = RequestMethod.POST)    //GET will be take
	public String home(Model model) {
		System.out.println("this is home page");
		model.addAttribute("name", "UPadhyay");
		model.addAttribute("id", 1426);
		
		List<String> friends=new ArrayList<String>();
		friends.add("vancdana");
		friends.add("sunita");
		
		model.addAttribute("f", friends);
		return "index";
	}
	
	@RequestMapping("/about")
	public String  about() {
		System.out.println("this is about controller");
		return "about";
	}
	@RequestMapping("/services")
	public String services() {
		System.out.println("this is services provided by me");
		return "services";
	}

	
	
	
// for model and view	
	@RequestMapping("/help")
	public ModelAndView help() {
		System.out.println("how can I help you");
		
//		creating and model and view object
		ModelAndView modelAndView=new ModelAndView();
		
//setting the object		
		modelAndView.addObject("name", "Uttam SHukla");
		modelAndView.addObject("rollnumber", 1215);
		LocalDateTime now=LocalDateTime.now();
		modelAndView.addObject("time", now);
		
		//kmarks
		List<Integer> list=new ArrayList<Integer>();
		list.add(22);
		list.add(34);
		list.add(152);
		list.add(15222);
		
		modelAndView.addObject("marks",list);
//setting the view name		
		modelAndView.setViewName("help");
		
		return modelAndView;
	}
}
