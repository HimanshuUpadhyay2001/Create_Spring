package springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class ReController {

	@RequestMapping("/one")
	public RedirectView one() {								//public string one()
		System.out.println("this is one handler");
	RedirectView redirectView=new RedirectView();
	redirectView.setUrl("https://www.google.com");
				//		return "redirect:/enjoy";							//redirect prefix
		return redirectView;
	}
	@RequestMapping("/enjoy")
	public String two() {
		System.out.println("this is second handle");
		return "contact";
	}
}
