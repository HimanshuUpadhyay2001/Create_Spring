<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
	<%@page import="java.time.LocalDateTime" %>
	<%@page isELIgnored="false" %>
	
  <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Help us</title>
</head>
<body>

	<h1>how can i help you</h1>
	<h2>may i help you</h2>
	<%
	/*	String name = (String) request.getAttribute("name");
		Integer rollnumber = (Integer) request.getAttribute("rollnumber");
		LocalDateTime time=(LocalDateTime) request.getAttribute("time");
	*/
	%>
	<h1>
		Hello my name is
<%-- 		<%=name%>--%>
		${name }
</h1>  
	<h2>
		Rollnumber is
<%-- 		<%=rollnumber%>--%>
		${rollnumber }
	</h2>
		
		<h2>
		Date and Time is
<%-- 	<%=time%>--%>	
		${time }
</h2>

<hr>
<c:forEach var="item" items="${marks }">
<h1>${item }</h1>
</c:forEach>
</body>
</html>