package com.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.entities.Student;
import com.spring.jdbc.dao.StudentDao;
public class App 
{
    public static void main( String[] args )
    {
    	
        System.out.println( "My program is started" );
        // spring jdbc   jdbc template
        
 // ApplicationContext con= new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
  
        ApplicationContext con=new AnnotationConfigApplicationContext(JavaConfig.class);
//FOR MAINLY USE AS a direct value should be stored
        // JdbcTemplate template=con.getBean("jdbcTemplate", JdbcTemplate.class);
        //insert query
        //String query="insert into student(id, name, city) values(?,?,?)";
        //fire the query
       // int result=template.update(query, 11,"manish", "agra");
       //System.out.println("number of record inserted.." +result);
        
        
       
        
        
        
// for insert into teh database
        StudentDao studentDao=con.getBean("studentDao", StudentDao.class);
      /*  Student student=new Student();
        student.setId(1001);
        student.setName("Moni");
        student.setCity("Agra");
         int result= studentDao.insert(student);
        System.out.println("student added :"+result);
        */     
 
        
// for update into teh database        
      //  StudentDao studentDao=con.getBean("studentDao", StudentDao.class);
      //  Student student=new Student();
    /*    student.setId(100);
        student.setName("papa");
        student.setCity("sadabad");
        int r=studentDao.change(student);
        System.out.println("data changed " +r);
      */  
        
// for delete the rowin to the databases        
       // StudentDao studentDao=con.getBean("studentDao", StudentDao.class);
     /*  
        int s=studentDao.delete(1);
        System.out.println("data changed " +s);
       */ 
        
        
 // ofor single row find out       
     /*   Student student1=studentDao.getStudent(10);
        System.out.println(student1);
    */
        
        
  // for list of studetns
        List<Student> students=studentDao.getAllStudents();
        for(Student s: students) {
        	System.out.println(students);
        }
    }
}
