package com.spring.jdbc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.spring.entities.Student;

@Component("studetnDao")
public class StudentDaoImpl implements StudentDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
//  for setinto data base
	public int insert(Student student) {
		// TODO Auto-generated method stub
		   String query="insert into student(id, name, city) values(?,?,?)";
		   int r=this.jdbcTemplate.update(query,student.getId(), student.getName(), student.getCity());
		return r;
	}
	
	
// for query update
	public int change(Student student) {
		// TODO Auto-generated method stub
		String query="update student set name=?, city=? where id=?";
		int r=this.jdbcTemplate.update(query, student.getName(), student.getCity(), student.getId());
		return r;
	}
	
	
// for deleted the data
	public int delete(int studentId) {
		// TODO Auto-generated method stub
		String query="delete from student where id=?";
				int r=this.jdbcTemplate.update(query, studentId);
		return r;
	}
	
// for select student data
	public Student getStudent(int studentId) {
		// TODO Auto-generated method stub
		String query="select * from student where id=?";
			RowMapper<Student> rowMapper=new RowMappperImpl();
			Student student=this.jdbcTemplate.queryForObject(query, rowMapper, studentId);
		return student;
	}
	
// for select multiple studeent
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		String query="select * from student";
		List<Student> students=this.jdbcTemplate.query(query, new RowMappperImpl());
		return students;
	}
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	
}
