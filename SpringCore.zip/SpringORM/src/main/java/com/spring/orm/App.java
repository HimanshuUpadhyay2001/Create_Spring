package com.spring.orm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.dao.StudentDao;
import com.spring.orm.entities.Student;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
       ApplicationContext context =new ClassPathXmlApplicationContext("com/spring/orm/Config.xml");
       StudentDao studentDao=(StudentDao)context.getBean("studentDao", StudentDao.class);
     /*  
       Student student=new Student(1, "himanshu", "jalesr");
       int r=studentDao.insert(student);
       System.out.println("done" +r);
     */
       
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
     boolean go=true;
       while(go) {
       System.out.println("press 1 for add nwe Student");
       System.out.println("press 2 for display all Student");
       System.out.println("press 3 for display single Student");
       System.out.println("press 4 for delete Student");
       System.out.println("press 5 for update Student");
       System.out.println("press 6 for exit");
      try {
    	  int input=Integer.parseInt(br.readLine());
    	  switch (input) {
		case 1:
			//add a new studetnt
//taking input from users
			System.out.println("Enter user id : ");
			int uId=Integer.parseInt(br.readLine());
			
			System.out.println("Enter user name : ");
			String uName=br.readLine();
			
			System.out.println("Enter user city : ");
			String uCity=br.readLine();
//create studetn obejct
			Student s=new Student();
			s.setStudentId(uId);
			s.setStudentName(uName);
			s.setStudentCity(uCity);
//saving object to dataabase
			int r=studentDao.insert(s);
			System.out.println(r+ "student added");
			System.out.println("6+++++++++++++++++++++++++++++++");
			System.out.println();
			
			
			break;
		case 2: 	
			//dispaly all sutdent
			List<Student> allStudents=studentDao.getAllStudents();
			for(Student st:allStudents)
			{
				System.out.println("Id : "+st.getStudentId());
				System.out.println("Name : "+st.getStudentName());
				
				System.out.println("city :"+st.getStudentCity());
				System.out.println("________________________________________________________________________");
			}
			break;
		case 3:
			//get single sutdent data
			System.out.println("Enter user id : ");
			int userId=Integer.parseInt(br.readLine());
			Student student=studentDao.getStudent(userId);
			System.out.println("Id : "+student.getStudentId());
			System.out.println("Name : "+student.getStudentName());
			
			System.out.println("city :"+student.getStudentCity());
			System.out.println("________________________________________________________________________");
			break;
		case 4:
			//delete student
			System.out.println("Enter user id : ");
			int id=Integer.parseInt(br.readLine());
			studentDao.deleteStudent(id);
			System.out.println("studetnt deleted..........");
			break;
		case 5:
			//upadte the sutdent
			
			break;	
		case 6:
			//	exit
			go= false;
			break;
			
		}
      }catch(Exception e) {
    	  System.out.println("invalid input try with another one!");
    	  System.out.println(e.getMessage());
      }
       }
       
       
       System.out.println("thank you for using my application");
       System.out.println("see you soon!");
    }
}
