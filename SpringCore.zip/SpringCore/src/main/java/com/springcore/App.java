package com.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
     /*  Value find out from xml file of the package
      */	
        ApplicationContext context =new ClassPathXmlApplicationContext("com/springcore/config.xml");
        Student student1=(Student) context.getBean("student1");
        Student student2=(Student) context.getBean("student2");
        Student student3=(Student) context.getBean("student3");
        
        System.out.println(student1);
        System.out.println(student2);
        System.out.println(student3);
    }
}
