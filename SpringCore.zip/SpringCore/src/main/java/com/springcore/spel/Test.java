package com.springcore.spel;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.common.TemplateAwareExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/spel/stereoconfig.xml"); 
		Demo d1=context.getBean("demo", Demo.class);
		System.out.println(d1);

		
		
		// this is not mandatory fo rthe expression languages
	/*	
		SpelExpressionParser t1= new SpelExpressionParser();
		Expression expression=t1.parseExpression("22+44");
		
		System.out.println(expression.getValue());
		
		*/
	}

}
